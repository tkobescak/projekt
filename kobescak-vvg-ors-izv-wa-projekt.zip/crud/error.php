<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" type="text/css" href="style.css">
    <meta charset="UTF-8">
    <title>Error</title>
</head>
<body>
    <div>
        <h1>Invalid Request</h1>
    </div>
    <div>
        <p>Sorry, you've made an invalid request. Please <a href="index.php">go back</a> and try again.</p>
    </div>
</body>
</html>

